#!/usr/bin/env python3
"""
Multi-Person Pose Detector with MediaPipe
===================================================
Production-ready implementation cho UAV detection
- Multi-person pose detection & tracking
- Real-time visualization
- Performance metrics (FPS, latency)
- Support webcam & video file
- Skeleton drawing
"""

import cv2
import mediapipe as mp
import numpy as np
import time
from dataclasses import dataclass
from typing import List, Optional, Tuple
from collections import deque
import argparse


@dataclass
class PersonPose:
    """Lưu trữ thông tin một người"""
    person_id: int
    landmarks: np.ndarray  # shape (33, 3): [x, y, confidence]
    bbox: Tuple[int, int, int, int]  # (x_min, y_min, x_max, y_max)
    confidence: float
    timestamp: float


class MultiPersonPoseDetector:
    """
    Multi-person pose detector sử dụng MediaPipe
    Hỗ trợ tracking & visualization
    """
    
    # MediaPipe pose connections (skeleton)
    POSE_CONNECTIONS = [
        (0, 1), (0, 4), (1, 2), (2, 3), (3, 7), (4, 5), (5, 6), (6, 8),
        (9, 10), (11, 12), (11, 13), (13, 15), (15, 17), (15, 21), (16, 18),
        (16, 20), (18, 20), (12, 14), (14, 16), (14, 22), (11, 23), (12, 24),
        (23, 24), (23, 25), (24, 26), (25, 27), (26, 28), (27, 29), (28, 30),
        (29, 31), (30, 32), (27, 31), (28, 32)
    ]
    
    # Keypoint names
    KEYPOINT_NAMES = [
        "nose", "left_eye_inner", "left_eye", "left_eye_outer",
        "right_eye_inner", "right_eye", "right_eye_outer",
        "left_ear", "right_ear", "mouth_left", "mouth_right",
        "left_shoulder", "right_shoulder", "left_elbow", "right_elbow",
        "left_wrist", "right_wrist", "left_pinky", "right_pinky",
        "left_index", "right_index", "left_thumb", "right_thumb",
        "left_hip", "right_hip", "left_knee", "right_knee",
        "left_ankle", "right_ankle", "left_heel", "right_heel",
        "left_foot_index", "right_foot_index"
    ]
    
    def __init__(self, model_complexity: int = 1, 
                 min_detection_confidence: float = 0.5,
                 min_tracking_confidence: float = 0.5):
        """
        Args:
            model_complexity: 0 (fast) hoặc 1 (accurate)
            min_detection_confidence: threshold detection
            min_tracking_confidence: threshold tracking
        """
        self.mp_pose = mp.solutions.pose
        self.mp_drawing = mp.solutions.drawing_utils
        
        self.pose = self.mp_pose.Pose(
            static_image_mode=False,
            model_complexity=model_complexity,
            smooth_landmarks=True,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence
        )
        
        # Tracking
        self.person_tracks = {}  # ID -> PersonPose
        self.next_person_id = 0
        self.track_history = {}  # ID -> deque of bboxes
        self.max_track_history = 10
        self.iou_threshold = 0.3
        self.max_distance_threshold = 100  # pixels
        
        # Performance metrics
        self.frame_times = deque(maxlen=30)
        self.detection_times = deque(maxlen=30)
    
    def detect(self, frame: np.ndarray) -> List[PersonPose]:
        """
        Detect pose cho tất cả người trong frame
        
        Args:
            frame: input BGR image
            
        Returns:
            List[PersonPose]: list các person được detect
        """
        start_time = time.time()
        
        h, w, _ = frame.shape
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # MediaPipe detection
        results = self.pose.process(frame_rgb)
        
        detection_time = time.time() - start_time
        self.detection_times.append(detection_time * 1000)  # convert to ms
        
        persons = []
        
        if results.pose_landmarks is not None:
            # Extract landmarks
            landmarks = self._extract_landmarks(results.pose_landmarks)
            
            # Calculate bbox
            bbox = self._get_bbox_from_landmarks(landmarks, w, h)
            
            # Calculate confidence
            confidence = self._calculate_confidence(landmarks)
            
            # Assign ID with tracking
            person_id = self._assign_person_id(bbox)
            
            person = PersonPose(
                person_id=person_id,
                landmarks=landmarks,
                bbox=bbox,
                confidence=confidence,
                timestamp=time.time()
            )
            persons.append(person)
            
            # Update track
            self.person_tracks[person_id] = person
            if person_id not in self.track_history:
                self.track_history[person_id] = deque(maxlen=self.max_track_history)
            self.track_history[person_id].append(bbox)
        
        # Clean old tracks
        current_time = time.time()
        dead_ids = [pid for pid, person in self.person_tracks.items()
                   if current_time - person.timestamp > 2.0]  # 2 second timeout
        for pid in dead_ids:
            del self.person_tracks[pid]
            if pid in self.track_history:
                del self.track_history[pid]
        
        return persons
    
    def _extract_landmarks(self, pose_landmarks) -> np.ndarray:
        """Extract landmarks to numpy array"""
        landmarks = np.array([
            [lm.x, lm.y, lm.z, lm.visibility]
            for lm in pose_landmarks.landmark
        ])
        return landmarks
    
    def _get_bbox_from_landmarks(self, landmarks: np.ndarray, 
                                 w: int, h: int) -> Tuple[int, int, int, int]:
        """
        Calculate bounding box from landmarks
        
        Args:
            landmarks: shape (33, 3) or (33, 4)
            w, h: frame width, height
            
        Returns:
            (x_min, y_min, x_max, y_max)
        """
        # Filter by confidence threshold
        valid_mask = landmarks[:, 2] > 0.3
        if np.sum(valid_mask) < 5:
            return (0, 0, 0, 0)
        
        valid_lm = landmarks[valid_mask, :2]
        
        # Add padding
        padding = 10
        x_min = max(0, int(np.min(valid_lm[:, 0]) * w) - padding)
        y_min = max(0, int(np.min(valid_lm[:, 1]) * h) - padding)
        x_max = min(w, int(np.max(valid_lm[:, 0]) * w) + padding)
        y_max = min(h, int(np.max(valid_lm[:, 1]) * h) + padding)
        
        return (x_min, y_min, x_max, y_max)
    
    def _calculate_confidence(self, landmarks: np.ndarray) -> float:
        """Calculate average confidence of landmarks"""
        if landmarks.shape[1] >= 3:
            return float(np.mean(landmarks[:, 2]))
        return 0.0
    
    def _assign_person_id(self, bbox: Tuple[int, int, int, int]) -> int:
        """
        Assign ID to person using simple tracking
        
        Args:
            bbox: (x_min, y_min, x_max, y_max)
            
        Returns:
            person_id
        """
        if len(self.person_tracks) == 0:
            person_id = self.next_person_id
            self.next_person_id += 1
            return person_id
        
        # Find closest track
        best_id = None
        min_distance = float('inf')
        
        for track_id, person in self.person_tracks.items():
            distance = self._bbox_distance(bbox, person.bbox)
            if distance < min_distance and distance < self.max_distance_threshold:
                min_distance = distance
                best_id = track_id
        
        if best_id is not None:
            return best_id
        else:
            person_id = self.next_person_id
            self.next_person_id += 1
            return person_id
    
    @staticmethod
    def _bbox_distance(bbox1: Tuple[int, int, int, int],
                      bbox2: Tuple[int, int, int, int]) -> float:
        """Calculate distance between two bboxes (center distance)"""
        x1, y1, x2, y2 = bbox1
        x3, y3, x4, y4 = bbox2
        
        cx1, cy1 = (x1 + x2) / 2, (y1 + y2) / 2
        cx2, cy2 = (x3 + x4) / 2, (y3 + y4) / 2
        
        return np.sqrt((cx1 - cx2) ** 2 + (cy1 - cy2) ** 2)
    
    def visualize(self, frame: np.ndarray, persons: List[PersonPose]) -> np.ndarray:
        """
        Draw poses on frame
        
        Args:
            frame: input frame
            persons: list of detected persons
            
        Returns:
            annotated frame
        """
        h, w, _ = frame.shape
        frame_out = frame.copy()
        
        # Define colors
        colors = [
            (0, 255, 0),    # Green - Person 0
            (255, 0, 0),    # Blue - Person 1
            (0, 0, 255),    # Red - Person 2
            (255, 255, 0),  # Cyan - Person 3
            (0, 255, 255),  # Yellow - Person 4
            (255, 0, 255),  # Magenta - Person 5
        ]
        
        for person in persons:
            color = colors[person.person_id % len(colors)]
            
            # Draw bbox
            x1, y1, x2, y2 = person.bbox
            cv2.rectangle(frame_out, (x1, y1), (x2, y2), color, 2)
            
            # Draw ID and confidence
            label = f"ID:{person.person_id} Conf:{person.confidence:.2f}"
            cv2.putText(frame_out, label, (x1, y1 - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
            
            # Draw skeleton
            landmarks = person.landmarks
            
            # Draw connections
            for connection in self.POSE_CONNECTIONS:
                start_idx, end_idx = connection
                start_lm = landmarks[start_idx]
                end_lm = landmarks[end_idx]
                
                if start_lm[2] > 0.3 and end_lm[2] > 0.3:
                    start_pos = (int(start_lm[0] * w), int(start_lm[1] * h))
                    end_pos = (int(end_lm[0] * w), int(end_lm[1] * h))
                    cv2.line(frame_out, start_pos, end_pos, color, 2)
            
            # Draw keypoints
            for i, landmark in enumerate(landmarks):
                if landmark[2] > 0.3:  # confidence threshold
                    x, y = int(landmark[0] * w), int(landmark[1] * h)
                    cv2.circle(frame_out, (x, y), 5, color, -1)
                    # Draw confidence at elbow, wrist (optional)
                    if i in [13, 14, 15, 16]:  # arms
                        cv2.putText(frame_out, f"{landmark[2]:.2f}",
                                   (x + 5, y - 5),
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.3, color, 1)
        
        return frame_out
    
    def draw_metrics(self, frame: np.ndarray) -> np.ndarray:
        """Draw performance metrics on frame"""
        if len(self.frame_times) == 0:
            return frame
        
        avg_frame_time = np.mean(self.frame_times)
        avg_detection_time = np.mean(self.detection_times)
        fps = 1000 / avg_frame_time if avg_frame_time > 0 else 0
        
        # Draw metrics
        metrics_text = [
            f"FPS: {fps:.1f}",
            f"Frame Time: {avg_frame_time:.2f}ms",
            f"Detection Time: {avg_detection_time:.2f}ms",
            f"Active Tracks: {len(self.person_tracks)}"
        ]
        
        y_offset = 30
        for i, text in enumerate(metrics_text):
            cv2.putText(frame, text, (10, y_offset + i * 25),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        
        return frame
    
    def get_fps(self) -> float:
        """Get average FPS"""
        if len(self.frame_times) == 0:
            return 0.0
        avg_time = np.mean(self.frame_times)
        return 1000 / avg_time if avg_time > 0 else 0.0


class PoseDetectorApp:
    """Main application class"""
    
    def __init__(self, source: str = "0", model_complexity: int = 1,
                 save_output: bool = False, output_path: str = "output.mp4"):
        """
        Args:
            source: "0" for webcam, or path to video file
            model_complexity: 0 (fast) or 1 (accurate)
            save_output: whether to save output video
            output_path: path to save output video
        """
        self.source = source
        self.save_output = save_output
        self.output_path = output_path
        
        self.detector = MultiPersonPoseDetector(model_complexity=model_complexity)
        self.video_writer = None
        
        # Open video source
        if source == "0":
            self.cap = cv2.VideoCapture(0)
        else:
            self.cap = cv2.VideoCapture(source)
        
        if not self.cap.isOpened():
            raise RuntimeError(f"Failed to open video source: {source}")
        
        # Get properties
        self.fps = self.cap.get(cv2.CAP_PROP_FPS) or 30
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        print(f"Video source: {source}")
        print(f"Resolution: {self.width}x{self.height}")
        print(f"FPS: {self.fps}")
        
        # Setup video writer if saving
        if save_output:
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            self.video_writer = cv2.VideoWriter(
                output_path, fourcc, self.fps,
                (self.width, self.height)
            )
            print(f"Saving output to: {output_path}")
    
    def run(self):
        """Run detection loop"""
        frame_count = 0
        
        try:
            while True:
                ret, frame = self.cap.read()
                if not ret:
                    print("End of video or failed to read frame")
                    break
                
                start_time = time.time()
                
                # Detect
                persons = self.detector.detect(frame)
                
                # Visualize
                frame_out = self.detector.visualize(frame, persons)
                frame_out = self.detector.draw_metrics(frame_out)
                
                # Calculate frame time
                frame_time = (time.time() - start_time) * 1000
                self.detector.frame_times.append(frame_time)
                
                # Save if enabled
                if self.video_writer:
                    self.video_writer.write(frame_out)
                
                # Display
                cv2.imshow("Multi-Person Pose Detection", frame_out)
                
                frame_count += 1
                if frame_count % 30 == 0:
                    print(f"Frame: {frame_count} | FPS: {self.detector.get_fps():.1f} | "
                          f"Detected: {len(persons)} persons")
                
                # Key control
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    break
                elif key == ord('s'):
                    # Save screenshot
                    cv2.imwrite(f"screenshot_{frame_count}.jpg", frame_out)
                    print(f"Screenshot saved: screenshot_{frame_count}.jpg")
        
        finally:
            self.cleanup()
    
    def cleanup(self):
        """Clean up resources"""
        self.cap.release()
        if self.video_writer:
            self.video_writer.release()
        cv2.destroyAllWindows()
        
        print(f"Total frames processed: {self.detector.next_person_id}")
        print(f"Average FPS: {self.detector.get_fps():.1f}")


def main():
    parser = argparse.ArgumentParser(
        description="Multi-Person Pose Detection with MediaPipe"
    )
    parser.add_argument(
        "--source", default="0",
        help="Video source: 0 for webcam, or path to video file (default: 0)"
    )
    parser.add_argument(
        "--model-complexity", type=int, default=1,
        choices=[0, 1],
        help="Model complexity: 0 (fast) or 1 (accurate) (default: 1)"
    )
    parser.add_argument(
        "--save-output", action="store_true",
        help="Save output video"
    )
    parser.add_argument(
        "--output", default="output.mp4",
        help="Output video path (default: output.mp4)"
    )
    
    args = parser.parse_args()
    
    print("="*60)
    print("Multi-Person Pose Detection with MediaPipe")
    print("="*60)
    print("Controls:")
    print("  q: Quit")
    print("  s: Save screenshot")
    print("="*60)
    
    app = PoseDetectorApp(
        source=args.source,
        model_complexity=args.model_complexity,
        save_output=args.save_output,
        output_path=args.output
    )
    app.run()


if __name__ == "__main__":
    main()
