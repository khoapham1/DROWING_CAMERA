#!/usr/bin/env python3
"""
ROS2 Humble Integration Example
===================================================
Node để publish pose detection results
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Point32, PolygonStamped
from cv_bridge import CvBridge
import cv2
import numpy as np

from multi_person_pose_detector import MultiPersonPoseDetector


class PoseDetectorNode(Node):
    """ROS2 Node for multi-person pose detection"""
    
    def __init__(self):
        super().__init__('multi_person_pose_detector')
        
        # Initialize detector
        self.detector = MultiPersonPoseDetector(
            model_complexity=0  # Use fast model for UAV
        )
        
        # CV bridge for image conversion
        self.bridge = CvBridge()
        
        # Subscribers
        self.image_subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10
        )
        
        # Publishers
        self.image_pub = self.create_publisher(
            Image, 
            '/pose_detector/image_annotated',
            10
        )
        
        self.pose_bbox_pub = self.create_publisher(
            PolygonStamped,
            '/pose_detector/bounding_boxes',
            10
        )
        
        self.get_logger().info('PoseDetectorNode initialized')
    
    def image_callback(self, msg: Image):
        """Process incoming camera image"""
        try:
            # Convert ROS image to OpenCV format
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            
            # Detect poses
            persons = self.detector.detect(frame)
            
            # Visualize
            frame_annotated = self.detector.visualize(frame, persons)
            frame_annotated = self.detector.draw_metrics(frame_annotated)
            
            # Publish annotated image
            self.image_pub.publish(
                self.bridge.cv2_to_imgmsg(frame_annotated, encoding='bgr8')
            )
            
            # Publish bounding boxes
            for person in persons:
                self.publish_bbox(person, msg.header)
            
            # Log info periodically
            if self.detector.next_person_id % 30 == 0:
                self.get_logger().info(
                    f"Detected {len(persons)} persons | FPS: {self.detector.get_fps():.1f}"
                )
        
        except Exception as e:
            self.get_logger().error(f"Error in image callback: {e}")
    
    def publish_bbox(self, person, header):
        """Publish bounding box as polygon"""
        x1, y1, x2, y2 = person.bbox
        
        bbox_msg = PolygonStamped()
        bbox_msg.header = header
        
        # Define rectangle corners
        bbox_msg.polygon.points = [
            Point32(x=float(x1), y=float(y1), z=0.0),
            Point32(x=float(x2), y=float(y1), z=0.0),
            Point32(x=float(x2), y=float(y2), z=0.0),
            Point32(x=float(x1), y=float(y2), z=0.0),
        ]
        
        self.pose_bbox_pub.publish(bbox_msg)


def main(args=None):
    rclpy.init(args=args)
    
    node = PoseDetectorNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Shutdown requested')
    finally:
        rclpy.shutdown()


if __name__ == '__main__':
    main()


"""
ROS2 Setup Instructions
===================================================

1. Create workspace:
   mkdir -p ~/ros2_ws/src
   cd ~/ros2_ws

2. Clone/copy this file to ros2 package:
   mkdir -p src/pose_detector/pose_detector
   cp pose_detector_node.py src/pose_detector/pose_detector/

3. Create setup.py:
   cat > src/pose_detector/setup.py << 'EOF'
   from setuptools import setup

   setup(
       name='pose_detector',
       version='0.0.1',
       packages=['pose_detector'],
       install_requires=['setuptools'],
       entry_points={
           'console_scripts': [
               'pose_detector_node = pose_detector.pose_detector_node:main',
           ],
       },
   )
   EOF

4. Install dependencies:
   sudo apt install python3-cv-bridge

5. Build:
   cd ~/ros2_ws
   colcon build --packages-select pose_detector

6. Run:
   source install/setup.bash
   ros2 run pose_detector pose_detector_node

7. View results:
   # In another terminal
   source ~/ros2_ws/install/setup.bash
   ros2 topic echo /pose_detector/image_annotated
   
   # Or use RViz
   rviz2
   # Add Image display for /pose_detector/image_annotated

Topics
===================================================
Subscribers:
  /camera/image_raw (sensor_msgs/Image)

Publishers:
  /pose_detector/image_annotated (sensor_msgs/Image)
    - Annotated frame with poses drawn
  
  /pose_detector/bounding_boxes (geometry_msgs/PolygonStamped)
    - Bounding boxes for each detected person
"""
