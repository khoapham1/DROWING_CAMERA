#!/usr/bin/env python3
"""
Quick Start Example
===================================================
Cách đơn giản nhất để dùng multi-person pose detector
"""

import cv2
from multi_person_pose_detector import MultiPersonPoseDetector


def main():
    # Khởi tạo detector
    detector = MultiPersonPoseDetector(model_complexity=1)
    
    # Mở camera
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        print("Error: Cannot open camera")
        return
    
    print("Press 'q' to quit, 's' to save screenshot\n")
    
    frame_count = 0
    
    while True:
        # Đọc frame từ camera
        ret, frame = cap.read()
        if not ret:
            break
        
        # Detect poses
        persons = detector.detect(frame)
        
        # Draw on frame
        frame_out = detector.visualize(frame, persons)
        frame_out = detector.draw_metrics(frame_out)
        
        # Show
        cv2.imshow("Multi-Person Pose Detection", frame_out)
        
        # Print info
        frame_count += 1
        if frame_count % 30 == 0:
            print(f"Frame {frame_count} | Detected {len(persons)} persons | "
                  f"FPS: {detector.get_fps():.1f}")
            
            # Print details of each detected person
            for person in persons:
                print(f"  - Person {person.person_id}: "
                      f"bbox={person.bbox}, conf={person.confidence:.2f}")
        
        # Key control
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            print("Quitting...")
            break
        elif key == ord('s'):
            cv2.imwrite(f"screenshot_{frame_count}.jpg", frame_out)
            print(f"Screenshot saved: screenshot_{frame_count}.jpg")
    
    cap.release()
    cv2.destroyAllWindows()
    print(f"Done! Processed {frame_count} frames")


if __name__ == "__main__":
    main()
