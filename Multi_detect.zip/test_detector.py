#!/usr/bin/env python3
"""
Test script cho MultiPersonPoseDetector
Demonstrates các features khác nhau
"""

import cv2
import numpy as np
import time
from multi_person_pose_detector import MultiPersonPoseDetector, PersonPose
from typing import List


def test_detector_on_webcam():
    """Test 1: Chạy detector trên webcam"""
    print("\n[TEST 1] Running detector on webcam...")
    print("Press 'q' to quit\n")
    
    detector = MultiPersonPoseDetector(model_complexity=1)
    cap = cv2.VideoCapture(0)
    
    frame_count = 0
    start_time = time.time()
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        persons = detector.detect(frame)
        frame_out = detector.visualize(frame, persons)
        frame_out = detector.draw_metrics(frame_out)
        
        cv2.imshow("Detector Test - Webcam", frame_out)
        
        frame_count += 1
        if frame_count % 30 == 0:
            elapsed = time.time() - start_time
            print(f"Frame {frame_count} | FPS: {frame_count/elapsed:.2f} | "
                  f"Detected: {len(persons)} persons")
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()
    print(f"✓ Test 1 completed. Total frames: {frame_count}\n")


def test_extract_landmarks():
    """Test 2: Extract keypoints từ detected persons"""
    print("[TEST 2] Extracting landmarks...")
    
    detector = MultiPersonPoseDetector(model_complexity=0)
    cap = cv2.VideoCapture(0)
    
    captured_persons = []
    frame_count = 0
    
    print("Capturing people (Press 'q' to stop)...\n")
    
    while len(captured_persons) < 3:  # Capture 3 persons
        ret, frame = cap.read()
        if not ret:
            break
        
        persons = detector.detect(frame)
        
        for person in persons:
            if person.person_id not in [p.person_id for p in captured_persons]:
                captured_persons.append(person)
                print(f"✓ Captured Person {person.person_id}")
        
        frame_out = detector.visualize(frame, persons)
        cv2.imshow("Extracting Landmarks - Press q to skip", frame_out)
        
        frame_count += 1
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()
    
    # Print landmarks
    print(f"\nExtracted {len(captured_persons)} persons:\n")
    for person in captured_persons:
        print(f"Person {person.person_id}:")
        print(f"  Confidence: {person.confidence:.3f}")
        print(f"  Bbox: {person.bbox}")
        print(f"  Landmarks shape: {person.landmarks.shape}")
        
        # Print key landmarks
        keypoint_names = ["Nose", "Left Shoulder", "Right Shoulder", 
                         "Left Elbow", "Right Elbow", "Left Wrist", "Right Wrist"]
        keypoint_ids = [0, 11, 12, 13, 14, 15, 16]
        
        print("  Key keypoints:")
        for name, idx in zip(keypoint_names, keypoint_ids):
            lm = person.landmarks[idx]
            if lm[2] > 0.3:
                print(f"    {name}: ({lm[0]:.3f}, {lm[1]:.3f}) conf={lm[2]:.3f}")
        print()
    
    print("✓ Test 2 completed\n")


def test_pose_similarity():
    """Test 3: Detect same pose bởi 2 people (similarity check)"""
    print("[TEST 3] Comparing poses from multiple people...")
    
    detector = MultiPersonPoseDetector(model_complexity=1)
    cap = cv2.VideoCapture(0)
    
    poses = {}
    frame_count = 0
    
    print("Detecting poses (capture at least 2 people)...\n")
    
    while len(poses) < 2 and frame_count < 300:  # 10 seconds @ 30 FPS
        ret, frame = cap.cap.read()
        if not ret:
            break
        
        persons = detector.detect(frame)
        
        for person in persons:
            if person.person_id not in poses:
                poses[person.person_id] = person
                print(f"✓ Captured pose from Person {person.person_id}")
        
        frame_out = detector.visualize(frame, persons)
        cv2.imshow("Pose Comparison", frame_out)
        
        frame_count += 1
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()
    
    # Compare poses
    if len(poses) >= 2:
        person_ids = list(poses.keys())
        pose1 = poses[person_ids[0]]
        pose2 = poses[person_ids[1]]
        
        similarity = _calculate_pose_similarity(pose1.landmarks, pose2.landmarks)
        print(f"\nPose similarity between Person {person_ids[0]} and {person_ids[1]}: "
              f"{similarity:.3f}")
        print("(1.0 = identical, 0.0 = completely different)\n")
    
    print("✓ Test 3 completed\n")


def test_tracking_stability():
    """Test 4: Check tracking stability"""
    print("[TEST 4] Testing tracking stability...")
    
    detector = MultiPersonPoseDetector(model_complexity=0)
    cap = cv2.VideoCapture(0)
    
    id_changes = []
    prev_positions = {}
    frame_count = 0
    
    print("Monitoring tracking (30 frames)...\n")
    
    while frame_count < 30:
        ret, frame = cap.cap.read()
        if not ret:
            break
        
        persons = detector.detect(frame)
        
        for person in persons:
            if person.person_id in prev_positions:
                x1, y1, x2, x2_val = person.bbox
                px1, py1, px2, px2_val = prev_positions[person.person_id]
                
                movement = np.sqrt((x1 - px1)**2 + (y1 - py1)**2)
                # print(f"Person {person.person_id} movement: {movement:.1f}px")
            
            prev_positions[person.person_id] = person.bbox
        
        frame_out = detector.visualize(frame, persons)
        cv2.imshow("Tracking Stability", frame_out)
        
        frame_count += 1
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()
    
    print(f"Tracked IDs: {list(prev_positions.keys())}")
    print(f"Stable tracking: {len(prev_positions)} unique person(s)\n")
    print("✓ Test 4 completed\n")


def test_performance():
    """Test 5: Performance benchmark"""
    print("[TEST 5] Performance benchmark...")
    print("Processing 100 frames...\n")
    
    detector = MultiPersonPoseDetector(model_complexity=0)
    cap = cv2.VideoCapture(0)
    
    times = []
    frame_count = 0
    
    while frame_count < 100:
        ret, frame = cap.cap.read()
        if not ret:
            break
        
        start = time.time()
        persons = detector.detect(frame)
        detect_time = (time.time() - start) * 1000
        
        times.append(detect_time)
        
        frame_out = detector.visualize(frame, persons)
        cv2.imshow("Performance Test", frame_out)
        
        frame_count += 1
        if frame_count % 20 == 0:
            print(f"Frame {frame_count}...")
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()
    
    times = np.array(times)
    print(f"\n=== Performance Results ===")
    print(f"Total frames: {frame_count}")
    print(f"Average latency: {np.mean(times):.2f}ms")
    print(f"Min latency: {np.min(times):.2f}ms")
    print(f"Max latency: {np.max(times):.2f}ms")
    print(f"Std deviation: {np.std(times):.2f}ms")
    print(f"Average FPS: {1000/np.mean(times):.1f}")
    print()
    print("✓ Test 5 completed\n")


def _calculate_pose_similarity(lm1: np.ndarray, lm2: np.ndarray) -> float:
    """Calculate similarity between two poses"""
    valid_mask = (lm1[:, 2] > 0.3) & (lm2[:, 2] > 0.3)
    
    if np.sum(valid_mask) < 5:
        return 0.0
    
    lm1_valid = lm1[valid_mask, :2]
    lm2_valid = lm2[valid_mask, :2]
    
    # Normalize
    lm1_norm = (lm1_valid - np.mean(lm1_valid, axis=0)) / (np.std(lm1_valid, axis=0) + 1e-6)
    lm2_norm = (lm2_valid - np.mean(lm2_valid, axis=0)) / (np.std(lm2_valid, axis=0) + 1e-6)
    
    # Cosine similarity
    similarity = np.mean([np.dot(lm1_norm[i], lm2_norm[i]) / 
                         (np.linalg.norm(lm1_norm[i]) * np.linalg.norm(lm2_norm[i]) + 1e-6)
                         for i in range(len(lm1_norm))])
    
    return max(0, similarity)


def main():
    print("\n" + "="*60)
    print("MultiPersonPoseDetector - Test Suite")
    print("="*60)
    print("\nAvailable tests:")
    print("1. Detector on webcam")
    print("2. Extract landmarks")
    print("3. Pose similarity")
    print("4. Tracking stability")
    print("5. Performance benchmark")
    print("0. Run all tests")
    print("="*60 + "\n")
    
    choice = input("Select test (0-5): ").strip()
    
    if choice == "1":
        test_detector_on_webcam()
    elif choice == "2":
        test_extract_landmarks()
    elif choice == "3":
        test_pose_similarity()
    elif choice == "4":
        test_tracking_stability()
    elif choice == "5":
        test_performance()
    elif choice == "0":
        test_detector_on_webcam()
        test_extract_landmarks()
        test_pose_similarity()
        test_tracking_stability()
        test_performance()
    else:
        print("Invalid choice")


if __name__ == "__main__":
    main()
